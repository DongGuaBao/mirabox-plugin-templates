# mirabox-plugin-sdk 宿主协议对照

核对日期为 2026-11-24。StreamDock 插件文档（wiki-e7gidk72）的中文原文位于 `zh-cn/guide/`，Craft 插件文档（wiki-0mpkl15e）位于 `zh/guide/`。两库均对照了 `registration.md`、`events-received.md`、`events-sent.md` 和 `manifest.md`。以下约定供使用 Node 和 Web 后端的插件作者参考。

| 能力 | StreamDock | Craft |
| --- | --- | --- |
| Web 注册入口 | `connectElgatoStreamDeckSocket` | `connectMiraBoxSDSocket`。后端 4 个参数，PI 另有 actionInfo |
| 实例尺寸 | manifest 使用 SDKVersion 3 时，读取当次事件的 `payload.width/height`。老宿主可能省略；Card 收到有效尺寸时按它重绘 | 使用 `settings.ActionGeometry`。启动事件的 `deviceWidth/deviceHeight/deviceType` 描述整台设备 |
| 触摸与旋钮 | Mira75 Card 使用 `touchTap`，其他触摸 Card 使用 `touchEvent` 的 down、move、up、cancel；旋钮上报的 Encoder 和 Knob 均映射成 `actionType === "Knob"` | 组件使用 SecondaryScreen，交互由宿主处理 |
| 图像 | `action.setImage(image, { target, state })` 和 `setTitle` 支持按显示目标、状态输出 | `action.setImage(image)` 或 `await action.setImageBlob(encodedImage, mime)`。后者接收 Blob 或已经编码的 Uint8Array/Node Buffer，字节可以是 WebP、PNG 等；连续异步编码时按帧顺序 await |
| 宿主命令 | `plugin.getSettings()`、`pi.getSettings()` 的结果通过 didReceiveSettings 返回。后端和 PI 均可调用 logMessage。切换场景用 `plugin.switchToProfile(device, profile?, page?)`，第 1 页传 1；超级热键用 `action.triggerKey(keyList)` | 全屏提示使用 `plugin.lightControl({ active: true, ... })`，告警结束时传 `{ active: false }`。全局设置命令按 Craft 协议省略 context |
| PI 回复 | Action 使用自己的 action UUID 和 context，插件级单参数方法发送给当前选中的 PI | 从 Action 回复。Craft 没有 PI 显隐事件，实例路由可直接工作 |

## Craft 发送原始像素

`action.setImageRGBA(imageData, width, height)` 接收逐行排列的 RGBA8 像素。Canvas 可直接传 `getImageData(...).data`；Node 后端可传 `Uint8Array` 或 `Buffer`。`plugin.setImageRGBA(context, imageData, width, height)` 显式指定实例。宽高为正整数，视图长度必须等于 `width × height × 4`。每次调用会复制当前视图，调用后可以立即复用输入数组。图片沿用 SDK 的有界发送队列。

## PI 调用示例

```ts
interface Backend {
    readValue(id: number): string;
}
const pi = Property.getReactiveInstance();
const backend = pi.getPluginProxy<Backend>(3000);
const value = await backend.readValue(1);
```

`callPlugin()` 的默认超时为 10 秒。`getPluginProxy()` 兼容已有的无限等待行为，交互按钮可传毫秒数限定等待时间。方法不存在或连接关闭时 Promise 会拒绝，调用方可在 `catch` 中提示用户重试。
